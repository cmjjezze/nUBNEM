/**
 * @description
 * Entry file for The Province Man's Web App
 */
const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const homeRouter = require('./server/routers/homeRouter');
const mainRouter = require('./server/routers/mainRouter');
const cardsRouter = require('./server/routers/cardsRouter');
const port = 3300;

app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));


app.use((req, res, next) => {
  req.viewModel = {
    title: 'nUB'
  };
  next();
});

app.set('views', path.join(__dirname, 'server/views/'));
app.set('view engine', 'pug');

app.use('/', homeRouter);
app.use('/main', mainRouter);
app.use('/api/cards', cardsRouter);

app.listen(port, (err) => {
  if(err) { return console.error(err); }
  console.log(`Listening to ${port}...`);
});
