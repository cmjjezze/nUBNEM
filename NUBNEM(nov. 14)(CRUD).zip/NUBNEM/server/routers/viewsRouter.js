/**
 * HomeRouter

 */
const express = require('express');
const router = express.Router(); //eslint-disable-line
const SimpleJsonStore = require('simple-json-store');

// Initializes the data-2.json file with notes as its initial value if empty
const store = new SimpleJsonStore('./data.json', { cards: [] });

router.get('/', function getAddPage(req, res) {
  let viewModel = req.viewModel;
  viewModel.notes = store.get('cards');
  res.render('homePage/views.pug', viewModel);
});

router.post('/', function submitCards(req, res) {
  // Process: Get notes from json -> Add new card -> Save the card
  let cards = store.get('cards');
  cards.push({
    refNumber: req.body.refNumber,
    cardNumber: req.body.cardNumber,
    cardType: req.body.cardType,
    cardHolder: req.body.cardHolder,
    addressStreet: req.body.addressStreet,
    addressBrgy: req.body.addressBrgy,
    addressCity: req.body.addressCity,
    emailAddress: req.body.emailAddress,
    cardExpiration: req.body.cardExpiration,
    cardAnniversary: req.body.cardAnniversary,
    cardStatus: req.body.cardStatus
  });
  store.set('cards', cards);

  //- It just reload the page on /
  // More on redirection: https://developer.mozilla.org/en-US/docs/Web/HTTP/Redirections
  res.redirect('/');
});

// router.put('/:refNumber', (req, res) => {
//   const refNumber = req.params.refNumber;
//   const cards = store.get('cards');

//   for(let i = 0; i < cards.length; i++) {
//     if(cards[i].refNumber === refNumber) {
//       cards[i].cardNumber = req.body.cardNumber;
//       cards[i].cardType = req.body.cardType;
//       cards[i].cardHolder = req.body.cardHolder;
//       cards[i].addressStreet = req.body.addressStreet;
//       cards[i].addressBrgy = req.body.addressBrgy;
//       cards[i].addressCity = req.body.addressCity;
//       cards[i].emailAddress = req.body.emailAddress;
//       cards[i].cardExpiration = req.body.cardExpiration;
//       cards[i].cardAnniversary = req.body.cardAnniversary;
//       cards[i].cardStatus = req.body.cardStatus;
//       break;
//     }
//   }

//   store.set('cards', cards);
//   res.json(store.get('cards'));
// });

module.exports = router;
