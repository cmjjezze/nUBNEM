/**
 * cardsRouter.js
 */
const express = require('express');
const router = express.Router(); //eslint-disable-line
const SimpleJsonStore = require('simple-json-store');

const store = new SimpleJsonStore('./data.json', { cards: [] });

router.get('/', (req, res, next) => {
  console.log('Index page only');
  next();
}, (req, res) => {
  res.json(store.get('cards'));
});

router.get('/:refNumber', (req, res) => {
  let card = {};
  const cards = store.get('cards');
  card = cards.find(cards => cards.refNumber === req.params.refNumber);
  res.json(card);
});

router.post('/', (req, res) => {
  const cards = store.get('cards');
  const newCard = {
    refNumber: cards.length > 0 ? cards[cards.length - 1].refNumber + 1 : 1,
    cardNumber: req.body.cardNumber,
    cardType: req.body.cardType,
    cardHolder: req.body.cardHolder,
    addressStreet: req.body.addressStreet,
    addressBrgy: req.body.addressBrgy,
    addressCity: req.body.addressCity,
    emailAddress: req.body.emailAddress,
    cardExpiration: req.body.cardExpiration,
    cardAnniversary: req.body.cardAnniversary
  };

  cards.push(newCard);
  store.set('cards', cards);

  res.json(cards);
});

router.put('/:refNumber', (req, res) => {
  const refNumber = req.params.refNumber;
  const cards = store.get('cards');

  for(let i = 0; i < cards.length; i++) {
    if(cards[i].refNumber === refNumber) {
      cards[i].cardNumber = req.body.cardNumber;
      cards[i].cardType = req.body.cardType;
      cards[i].cardHolder = req.body.cardHolder;
      cards[i].addressStreet = req.body.addressStreet;
      cards[i].addressBrgy = req.body.addressBrgy;
      cards[i].addressCity = req.body.addressCity;
      cards[i].emailAddress = req.body.emailAddress;
      cards[i].cardExpiration = req.body.cardExpiration;
      cards[i].cardAnniversary = req.body.cardAnniversary;
      break;
    }
  }

  store.set('cards', cards);
  res.json(store.get('cards'));
});

router.delete('/:refNumber', (req, res) => {
  const refNumber = req.params.refNumber;
  const cards = store.get('cards');
  const newCards = cards.filter(card => Number(card.refNumber) !== Number(refNumber));

  store.set('cards', newCards);
  res.json(newCards);
});

module.exports = router;
