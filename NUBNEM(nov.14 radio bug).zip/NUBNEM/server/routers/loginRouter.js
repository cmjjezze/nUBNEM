/**
 * HomeRouter

 */
const express = require('express');
const router = express.Router(); //eslint-disable-line
const SimpleJsonStore = require('simple-json-store');

// Initializes the data-2.json file with notes as its initial value if empty
const store = new SimpleJsonStore('./data.json', { cards: [] });

router.get('/', function getAddPage(req, res) {
  let viewModel = req.viewModel;
  viewModel.notes = store.get('cards');
  res.render('homePage/login.pug', viewModel);
});

router.post('/', function submitCards(req, res) {
  // Process: Get notes from json -> Add new card -> Save the card
  let cards = store.get('cards');
  cards.push({
    cardNumber: req.body.cardNumber,
    cardType: req.body.cardType,
    cardHolder: req.body.cardHolder,
    addressStreet: req.body.addressStreet,
    addressBrgy: req.body.addressBrgy,
    addressCity: req.body.addressCity,
    emailAddress: req.body.emailAddress,
    cardExpiration: req.body.cardExpiration,
    cardAnniversary: req.body.cardAnniversary,
    cardStatusOne: req.body.cardStatusOne,
    cardStatusTwo: req.body.cardStatusTwo,
    cardStatusThr: req.body.cardStatusThr
  });
  store.set('cards', cards);

  //- It just reload the page on /
  // More on redirection: https://developer.mozilla.org/en-US/docs/Web/HTTP/Redirections
  res.redirect('/');
});

module.exports = router;
