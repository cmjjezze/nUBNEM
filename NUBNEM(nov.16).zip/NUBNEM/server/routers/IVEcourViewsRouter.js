/**
 * HomeRouter

 */
const express = require('express');
const router = express.Router(); //eslint-disable-line
const SimpleJsonStore = require('simple-json-store');

// Initializes the data-2.json file with notes as its initial value if empty
const store = new SimpleJsonStore('./data.json', { cards: [] });

router.get('/', function getAddPage(req, res) {
  let viewModel = req.viewModel;
  viewModel.notes = store.get('cards');
  res.render('IVEcourierPage/views.pug', viewModel);
});

// router.post('/', function submitCards(req, res) {
//   // Process: Get notes from json -> Add new card -> Save the card
//   let cards = store.get('cards');
//   cards.push({
//     cardNumber: req.body.cardNumber,
//     cardType: req.body.cardType,
//     cardHolder: req.body.cardHolder,
//     addressStreet: req.body.addressStreet,
//     addressBrgy: req.body.addressBrgy,
//     addressCity: req.body.addressCity,
//     emailAddress: req.body.emailAddress,
//     cardExpiration: req.body.cardExpiration,
//     cardAnniversary: req.body.cardAnniversary,
//     cardStatus: req.body.cardStatus,
//     cardStatusTwo: req.body.cardStatusTwo,
//     cardStatusThr: req.body.cardStatusThr,
//     courierName: req.body.courierName,
//     courierAttempt: req.body.courierAttempt,
//     courierRemarks: req.body.courierRemarks
//   });
//   store.set('cards', cards);

//   //- It just reload the page on /
//   // More on redirection: https://developer.mozilla.org/en-US/docs/Web/HTTP/Redirections
//   res.redirect('/');
// });

// router.get('/get/:IVE', (req, res) => {
//   const { IVE } = req.params;
//   const cards = store.get('cards');
//   const result = cards.filter(card => card.courierName === 'IVE');
//   return result;
// });

module.exports = router;
