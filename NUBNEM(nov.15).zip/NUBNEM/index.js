/**
 * @description
 * Entry file for The Province Man's Web App
 */
const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const loginRouter = require('./server/routers/loginRouter');
const homeRouter = require('./server/routers/homeRouter');
const mainRouter = require('./server/routers/mainRouter');
const viewsRouter = require('./server/routers/viewsRouter');
const cardsRouter = require('./server/routers/cardsRouter');
const IVEcourHomeRouter = require('./server/routers/IVEcourHomeRouter');
const IVEcourViewsRouter = require('./server/routers/IVEcourViewsRouter');
const port = 3300;

app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));


app.use((req, res, next) => {
  req.viewModel = {
    title: 'nUB'
  };
  next();
});

app.set('views', path.join(__dirname, 'server/views/'));
app.set('view engine', 'pug');

app.use('/', loginRouter);
app.use('/home', homeRouter);
app.use('/main', mainRouter);
app.use('/views', viewsRouter);
app.use('/IVEcourierHome', IVEcourHomeRouter);
app.use('/IVEcourierViews', IVEcourViewsRouter);
app.use('/api/cards', cardsRouter);

app.listen(port, (err) => {
  if(err) { return console.error(err); }
  console.log(`Listening to ${port}...`);
});
