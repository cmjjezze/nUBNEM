# nUB

This web app requires Node 8 or higher.

How to run the web app.

```
npm install
node index.js
```
