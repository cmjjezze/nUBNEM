(function() {
  var nemVue = new Vue({
    el: '#nemVue',
    data: {
      refNumber: null,
      cardNumber: null,
      cardType: null,
      cardHolder: null,
      addressStreet: null,
      addressBrgy: null,
      addressCity: null,
      emailAddress: null,
      cardExpiration: null,
      cardAnniversary: null,

      cards: []
    },
    created: function() {
      var self = this;
      axios.get('http://localhost:3300/api/cards')
        .then(function(res) {
          self.cards = res.data;
        })
        .catch(function(err) {
          self.cards = [];
        });
    },
    methods: {
      addNote: function() {
        var self = this;
        var payload = {
          cardNumber: self.cardNumber,
          cardType: self.cardType,
          cardHolder: self.cardHolder,
          addressStreet: self.addressStreet,
          addressBrgy: self.addressBrgy,
          addressCity: self.addressCity,
          emailAddress: self.emailAddress,
          cardExpiration: self.cardExpiration,
          cardAnniversary: self.cardAnniversary,
        };
        axios.post('/api/cards', payload)
          .then(function(res) {
            self.cards = res.data;
            self.clear();
          })
          .catch(function(err) {
          });
        alert('Successfully Added');
      },
      clear: function() {
        this.cardNumber = null;
        this.cardType = null;
        this.cardHolder = null;
        this.addressStreet = null;
        this.addressBrgy = null;
        this.addressCity = null;
        this.emailAddress = null;
        this.cardExpiration = null;
        this.cardAnniversary = null;
      },
      deleteNote: function(card) {
        var self = this;
        axios.delete('/api/cards/' + card.refNumber)
          .then(function(res) {
            var index = -1;
            for(var i = 0; i < self.cards.length; ++i) {
              if(Number(self.cards[i].refNumber) === Number(card.refNumber)) {
                index = i;
                break;
              }
            }
            self.cards.splice(index, 1);
          })
          .catch(function(err) {
          });
      },
      view: function(card) {
        this.title = card.title;
        this.cardNumber = card.cardNumber;
        this.cardType = card.cardType;
        this.cardHolder = card.cardHolder;
        this.addressStreet = card.addressStreet;
        this.addressBrgy = card.addressBrgy;
        this.addressCity = card.addressCity;
        this.emailAddress = card.emailAddress;
        this.cardExpiration = card.cardExpiration;
        this.cardAnniversary =  card.cardAnniversary;
        localStorage.setItem('RN', card.refNumber);
      },
      save: function() {
        const refNumber = localStorage.getItem('RN');
        var payload = {
          cardNumber: this.cardNumber,
          cardType: this.cardType,
          cardHolder: this.cardHolder,
          addressStreet: this.addressStreet,
          addressBrgy: this.addressBrgy,
          addressCity: this.addressCity,
          emailAddress: this.emailAddress,
          cardExpiration: this.cardExpiration,
          cardAnniversary: this.cardAnniversary,
        };
        axios.put('/api/cards/' + refNumber, payload)
          .then (function(res) {
            this.notes = res.data;
            //console.log(res.data);
            location.reload();
          })
          .catch (function(err){

          });
      }
    }
  });
  console.log(nemVue);
})();